#'@title Spectral
#'@description creates color spectal ramp
#'@keywords internal
#'@export
Spectral <- colorRampPalette(RColorBrewer::brewer.pal(11, "Spectral"))