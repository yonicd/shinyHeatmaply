#'@title BrBG
#'@description creates color BrBG ramp
#'@keywords internal
#'@export
BrBG <- colorRampPalette(RColorBrewer::brewer.pal(11, "BrBG"))